/*=========================================================================================
	File Name: compact-menu.js
	Description: Compact menu page level only
	----------------------------------------------------------------------------------------
	Item Name: Stack - Responsive Admin Theme
	Version: 2.1
	Author: Pixinvent
	Author URL: hhttp://www.themeforest.net/user/pixinvent
==========================================================================================*/
$(document).ready(function(){
	setTimeout(function(){
		$.app.menu.collapse();
	}, 100);
});