<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Whishlist extends Model
{
    //
}
