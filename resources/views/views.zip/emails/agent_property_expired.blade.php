<h2>Hello <span style="text-transform: capitalize">{{$property->agent->last_name}}</span></h2>
<h3>Your property has expired</h3>
<p>Property title: <strong>{{$property->title}}</strong></p>
<p>Please login to your <a href="#">account</a> to reactive your property</p>
<p>Thank you.</p>