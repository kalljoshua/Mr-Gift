<footer class="footer footer-static footer-dark navbar-border">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2 content">
        <span class="float-md-left d-block d-md-inline-block">&copy; 2018
            <a href="http://www.mrgiftuganda.com" target="_blank"
               class="text-bold-800 grey darken-2">Mr.Gift</a>. All Rights Reserved. </span>
</footer>